require("dotenv").config();

module.exports = {
    token: process.env.TOKEN || "MTI4NTIwNjI3MTQ4OTg2NzgxNg.G5g_2d.imNAmBLgFNOrlcbCUof-1z7NFsi3e6Q-VGwf4c",
    clientID: process.env.CLIENT_ID || "1285206271489867816", 
    prefix: process.env.PREFIX || ".", 
    ownerID: process.env.OWNER_ID || "1173547185758015498",
    SpotifyID: process.env.SPOTIFY_ID || "e6f84fbec2b44a77bf35a20c5ffa54b8",
    SpotifySecret: process.env.SPOTIFY_SECRET || "498f461b962443cfaf9539c610e2ea81",
    mongourl: process.env.MONGO_URL || "mongodb+srv://Kronix1:arjun@cluster0.ob9wwsc.mongodb.net/?retryWrites=true&w=majority",
    embedColor: process.env.EMBED_COLOR || 0xcc0000,
    logs: process.env.LOGS || "1285206634028859442",
    errorLogsChannel: process.env.ERROR_LOGS_CHANNEL || "1285206634028859442",
    buglogschannel: process.env.BUG_LOGS_CHANNEL || "1285206634028859442",
    SearchPlatform: "youtube",
    AggregatedSearchOrder: process.env.AGGREGATED_SEARCH_ORDER || "youtube, youtube music, soundcloud",
    links: {
        img: process.env.IMG || 'https://cdn.discordapp.com/attachments/1272932978397417636/1284808695808786443/banner1.png?ex=66e94c57&is=66e7fad7&hm=be97a57284a9a5f9a9854e0780e63ad8828b8bbfe95ead55edcece09d87d48e3&', 
        support: process.env.SUPPORT || 'https://discord.gg/dVPVP3nZEA',
        invite: process.env.INVITE || 'https://discord.gg/dVPVP3nZEA' 
    },
    nodes: [
        {
            host: process.env.NODE_HOST || "v3.lavalink.rocks",
            port: parseInt(process.env.NODE_PORT || "443"),
            password: process.env.NODE_PASSWORD || "horizxon.tech",
            secure: parseBoolean(process.env.NODE_SECURE || "true"),
        }
    ],
};

function parseBoolean(value) {
    if (typeof value === 'string') {
        value = value.trim().toLowerCase();
    }
    switch (value) {
        case true:
        case "true":
            return true;
        default:
            return false;
    }
}
