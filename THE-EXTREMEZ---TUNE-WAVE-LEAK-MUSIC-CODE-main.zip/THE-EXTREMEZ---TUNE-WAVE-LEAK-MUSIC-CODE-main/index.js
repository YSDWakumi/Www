const { EmbedBuilder, ActionRowBuilder, ButtonStyle, StingSelectMenuBuilder, Events, ButtonBuilder, editEmbed, Collection } = require("discord.js");
const MusicBot = require("./structures/Client");
const client = new MusicBot();
const GiveawayManager = require("./handlers/GiveawayManager");
client.connect()
const util = require('./handlers/util');
const config = require('./config');

client.util = new util(client);
client.giveawaysManager = new GiveawayManager(client);
client.emoji = {
  'tick': '✅',
  'cross': '❌',
  'dot': '・',
  'giveaway': '🎁',
  'music': '🎶',
  'volumehigh': '🔊',
  'play': '⏯️',
  'stop': '▶️',
  'skip': '↪️',
  'resume': '▶️'
};

client.userSettings = new Collection();
client.color = 'cc0000';

module.exports = client;

client.on(Events.InteractionCreate, async interaction => {

    if (!interaction.isStringSelectMenu()) return;

    process.on('unhandledRejection', (reason, p) => {
        console.log(reason, p);
    });

    process.on('uncaughtException', (err, origin) => {
        console.log(err, origin);
    });

    process.on('uncaughtExceptionMonitor', (err, origin) => {
        console.log(err, origin);
    });

    let options = interaction.values;
    let funny = options[0];

    if(funny === 'seven') {
        const embed7 = new EmbedBuilder()
            .setColor(client.color)
            .setFooter({ text: `Requested by ` + interaction.member.user.username, iconURL: interaction.member.user.displayAvatarURL({ dynamic: true }) })
            .setAuthor({name: `Help Panel`, iconURL: client.user.displayAvatarURL()})
            .setTitle("**__Image__**")
            .setDescription(`\n\n\`achi, fuck, slap, cat, dog, meeting\`\n\n`);
        interaction.update({embeds: [embed7], ephemeral: true});
        return;
    }

    if(funny === 'sixth') {
        const embed6 = new EmbedBuilder()
            .setAuthor({name:`Help Panel`, iconURL:client.user.displayAvatarURL()})
            .setTitle("**__Moderation__**")
            .setDescription(`\n\n\`lock, unlock, lockall, unlockall, hide, unhide, hideall, unhideall, ban, hackban, unban, unbanall, kick, mute, unmute, purge, nuke, purgebots\`\n\n`)
            .setThumbnail(client.user.displayAvatarURL())
            .setColor(client.color)
            .setTimestamp()
            .setFooter({ text: `Requested by ` + interaction.member.user.username, iconURL: interaction.member.user.displayAvatarURL({ dynamic: true })});
        interaction.update({ embeds: [embed6], ephemeral: true });
        return;
    }

    if(funny === 'fifth') {
        const embed2 = new EmbedBuilder()
            .setAuthor({name:`Help Panel`, iconURL:client.user.displayAvatarURL()})
            .setDescription(`
            ・ Prefix on this server: \`${prefix}\`
            ・ Type **\`${prefix}\`help** for more info
            ・ Total commands: \`${client.commands.size}\`
            **[Invite Me](${config.links.invite}) | [Support HQ](${config.links.support})**
            `)
            .addFields([
                {
                    name: `**__ # Main Categories__**`,
                    value: `
                    🎶 Information
                    🎶 Music
                    🎶 Voice`,
                }
            ])
            .setThumbnail(client.user.displayAvatarURL())
            .setImage("https://cdn.discordapp.com/attachments/1272932978397417636/1284808695808786443/banner1.png?ex=66e94c57&is=66e7fad7&hm=be97a57284a9a5f9a9854e0780e63ad8828b8bbfe95ead55edcece09d87d48e3&")
            .setColor(client.color)
            .setFooter({ text: `Requested by ` + interaction.member.user.username, iconURL: interaction.member.user.displayAvatarURL({ dynamic: true })});
        interaction.update({ embeds: [embed2], ephemeral: true });
        return;
    }

    if(funny === 'first') {
        const embed4 = new EmbedBuilder()
            .setAuthor({name:`Help Panel`, iconURL:client.user.displayAvatarURL()})
            .setTitle("**__Information__**")
            .setDescription(`\n\n\`about, invite, ping, \`\n\n`)
            .setThumbnail(client.user.displayAvatarURL())
            .setColor(client.color)
            .setTimestamp()
            .setFooter({ text: `Requested by ` + interaction.member.user.username, iconURL: interaction.member.user.displayAvatarURL({ dynamic: true })});
        interaction.update({ embeds: [embed4], ephemeral: true });
        return;
    }

    if(funny === 'second') {
        const embed5 = new EmbedBuilder()
            .setAuthor({name:`Help Panel`, iconURL:client.user.displayAvatarURL()})
            .setTitle("**__Music__**")
            .setDescription(`\n\n\`play, join, leave, loop, Autoplay, pause, lyrics, nowplaying, previous, queue, resume, skip, remove, seek, volume, search, shuffle, grab, skipto, clearqueue, 247, filters, p_create, p_delete, p_savecurrent, p_savequeue, p_removetrack, p_load, p_info, p_list\`\n\n`)
            .setThumbnail(client.user.displayAvatarURL())
            .setColor(client.color)
            .setTimestamp()
            .setFooter({ text: `Requested by ` + interaction.member.user.username, iconURL: interaction.member.user.displayAvatarURL({ dynamic: true })});
        interaction.update({ embeds: [embed5], ephemeral: true });
        return;
    }

    if(funny === 'fourth') {
        const embed6 = new EmbedBuilder()
            .setAuthor({name:`Help Panel`, iconURL:client.user.displayAvatarURL()})
            .setTitle("**__Settings__**")
            .setDescription(`\n\n\`adddj, removedj, toggledj, prefix\`\n\n`)
            .setThumbnail(client.user.displayAvatarURL())
            .setColor(client.color)
            .setTimestamp()
            .setFooter({ text: `Requested by ` + interaction.member.user.username, iconURL: interaction.member.user.displayAvatarURL({ dynamic: true })});
        interaction.update({ embeds: [embed6], ephemeral: true });
        return;
    }


  if(funny === 'eleventh') {
  const embed6 = new EmbedBuilder()
    .setAuthor({name:`Help Panel`,
      iconURL:client.user.displayAvatarURL()})
    .setTitle("**Voice**")
      .setDescription(`\n\n\`vcmute, vcunmute, vcdeafen, vcundeafen, vckick, vclist, vcmove\`\n\n`)
  .setThumbnail(client.user.displayAvatarURL())
    .setColor(client.color)
    .setTimestamp()
    .setFooter({ text: `Requested by ` + interaction.member.user.username , iconURL: interaction.member.user.displayAvatarURL({ dynamic: true})})

        interaction.update({ embeds: [embed6], ephemeral: true })
        return
  }
  if(funny === 'owner') {
    const embed6 = new EmbedBuilder()
      .setAuthor({name:`Help Panel`,
        iconURL:client.user.displayAvatarURL()})
      .setTitle("**__Owner__**")
        .setDescription(`\n\n\`eval, leaveserver, noprefix, reload, say, serverlist\`\n\n`)
    .setThumbnail(client.user.displayAvatarURL())
      .setColor(client.color)
      .setTimestamp()
      .setFooter({ text: `Requested by ` + interaction.member.user.username , iconURL: interaction.member.user.displayAvatarURL({ dynamic: true})})

          interaction.update({ embeds: [embed6], ephemeral: true })
          return
      }

module.exports = client;
})
