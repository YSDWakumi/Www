const { EmbedBuilder, version, Message } = require("discord.js");
const Discord = require('discord.js');
const moment = require("moment");
require("moment-duration-format");
const os = require("os");
const MusicBot = require("../../structures/Client");

module.exports = {
  name: "status",
  category: "Information",
  aliases: ["stats","st","botinfo","bi"],
  description: "Displays bot status.",
  args: false,
  usage: "",
  userPerms: [],
  owner: false,
  /**
   *
   * @param {Message} message
   * @param {string[]} args
   * @param {MusicBot} client
   * @param {string} prefix
   */
  execute: async (message, args, client, prefix) => {
      
      const guildsCounts = client.guilds.cache.size;
      const channelsCounts = client.channels.cache.size;
      const usercount = client.guilds.cache.reduce( (acc, guild) => acc + guild.memberCount, 0 );

      const duration = moment.duration(client.uptime).format("\`D\` [days], \`H\` [hrs], \`m\` [mins], \`s\` [secs]");
          const embed = new EmbedBuilder()
          .setAuthor({name: `Stats`, iconURL: client.user.displayAvatarURL()})
          .setFooter({text: `Requested by ` + message.author.username, iconURL: message.author.displayAvatarURL()})
          .setColor(client.color)
          .setTitle("Hey, It's  A Quality Music Bot With Breathtaking Feature")         
          .setDescription(`**!Stay Tuned**`)
     .addFields([{ name: '❣️ Bot\'s info' , value: ` ➡ _Bot Name_ : **${client.user.username}**\n ➡ _Bot ID_ : **${client.user.id}**\n ➡ _Shards_ : **${client.options.shardCount} _shards_**\n ➡ _Commands_ : **${client.commands.size} _commands_**`},
   { name: '❣️ Servers', value: `➡ _Servers_ : **${guildsCounts}** \n ➡ _Servers This Shard_ : **${client.options.shardCount}**\n ➡ _Members_ : **${usercount}**\n ➡ _Channels_ : **${channelsCounts}**\n ➡ _Created_ : **<t:${Math.round(client.user.createdTimestamp / 1000)}>**`},]);
          
const send = await message.reply({ embeds: [embed]});
          

  }
}