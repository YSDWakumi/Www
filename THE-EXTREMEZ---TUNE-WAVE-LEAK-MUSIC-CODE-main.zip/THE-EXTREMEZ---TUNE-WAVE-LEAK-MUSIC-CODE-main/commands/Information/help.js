const { EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder } = require("discord.js");
const config = require('../../config');

module.exports = {
    name: "help",
    category: "Information",
    aliases: ["h"],
    description: "",
    args: false,
    usage: "",
    userPerms: [],
    owner: false,
    execute: async (message, args, client, prefix) => {
        const embeds = generateEmbeds(client, prefix);
        await pagination(message, embeds);
    }
};

function generateEmbeds(client, prefix) {
    const helpEmbed = new EmbedBuilder()
        .setAuthor({ name: `Help Panel`, iconURL: client.user.displayAvatarURL() })
        .setDescription(`
        ➡ Prefix on this server: \`${prefix}\`
        ➡ Type **\`${prefix}\`help** for more info
        ➡ Total commands: \`${client.commands.size}\`
        **[Invite Me](${config.links.invite}) | [Support HQ](${config.links.support})**
        `)
        .addFields([
            {
                name: `**__#️ Main Categories__**`,
                value: `
                ・ Information
                ・ Music
                ・ Voice`,
            }
        ])
        .setThumbnail(client.user.displayAvatarURL())
        .setColor(client.color)
        .setTimestamp()
        .setImage("https://cdn.discordapp.com/attachments/1272932978397417636/1284808695808786443/banner1.png?ex=66e94c57&is=66e7fad7&hm=be97a57284a9a5f9a9854e0780e63ad8828b8bbfe95ead55edcece09d87d48e3&");

    const embeds = [
        helpEmbed,
        new EmbedBuilder()
            .setAuthor({ name: `Help Panel`, iconURL: client.user.displayAvatarURL() })
            .setTitle("**Information \`[20]\`**")
            .setDescription(`
            \`invite, ping, stats, help, afk, status, owner\`
            `)
            .setColor(client.color)
            .setTimestamp(),

        new EmbedBuilder()
            .setAuthor({ name: `Help Panel`, iconURL: client.user.displayAvatarURL() })
            .setTitle("**Music \`[30]\`**")
            .setDescription(`
            \`play, join, leave, loop, Autoplay, pause, lyrics, nowplaying, previous,
            queue, resume, skip, remove, seek, volume, search, shuffle, grab, skipto,
            clearqueue, 247, filters, p_create, p_delete, p_savecurrent, p_savequeue,
            p_removetrack, p_load, p_info, p_list\`
            `)
            .setColor(client.color)
            .setTimestamp(),

        new EmbedBuilder()
            .setAuthor({ name: `Help Panel`, iconURL: client.user.displayAvatarURL() })
            .setTitle("**Voice \`[6]\`**")
            .setDescription(`
            \`vcdeafen, vcundeafen, vclist, vcmute, vcunmute, vckick\`
            `)
            .setColor(client.color)
            .setTimestamp(),
    ];

    return embeds;
}

async function pagination(message, embeds) {
    const menu = new StringSelectMenuBuilder()
        .setCustomId('helpop')
        .setPlaceholder('🕊️ | Click to Browse Commands!')
        .addOptions([
            { label: 'Home', value: 'home', emoji: '🎶', description: 'Go Back To The Home Page' },
            { label: 'Information', value: 'information', emoji: '🎶', description: 'Get All Information Commands' },
            { label: 'Music', value: 'music', emoji: '🎶', description: 'Get All Music Commands' },
            { label: 'Voice', value: 'voice', emoji: '🎶', description: 'Get All Voice Commands' },
        ]);

    const row = new ActionRowBuilder().addComponents(menu);
    const currentPage = await message.channel.send({ embeds: [embeds[0]], components: [row] });

    const collector = currentPage.createMessageComponentCollector({ time: 60000 });

    collector.on('collect', async i => {
        if (i.user.id !== message.author.id) {
            return await i.reply({ content: "This interaction isn't for you!", ephemeral: true });
        }

        const embedIndex = getEmbedIndex(i.values[0]);
        await i.update({ embeds: [embeds[embedIndex]], components: [row] });
    });

    collector.on('end', () => currentPage.edit({ components: [] }));
}

function getEmbedIndex(selectedValue) {
    const embedMap = {
        'home': 0,
        'information': 1,  // Updated indices
        'music': 2,
        'voice': 3
    };
    return embedMap[selectedValue] ?? 0;  // Fallback to 0 if invalid value
}
